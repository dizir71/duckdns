#!/bin/bash

echo "🔍 Durchsuche aktuelle Konfigurationen nach 'host25.ssl-net.net'..."

# Liste der Dateitypen, in denen gesucht wird
EXTENSIONS="*.sh *.py *.conf *.ini *.txt *.json *.js"

# Wurzelverzeichnis (optional anpassen)
ROOT=~

# Backup-Suffix
BACKUP=".bak"

for ext in $EXTENSIONS; do
  find "$ROOT" -type f -name "$ext" 2>/dev/null | while read file; do
    if grep -q "host25.ssl-net.net" "$file"; then
      echo "🔧 Ersetze in: $file"
      cp "$file" "$file$BACKUP"
      sed -i '' 's/host25\.ssl-net\.net/host25.duckdns.org/g' "$file"
    fi
  done
done

echo "✅ Fertig. Backups mit Endung '.bak' wurden erstellt."
