Dieses Skript ersetzt alle Vorkommen von:

  host25.ssl-net.net → host25.duckdns.org

📁 Standardmäßig wird das Home-Verzeichnis (~) durchsucht.
Es werden nur folgende Dateitypen überprüft:
  *.sh, *.py, *.conf, *.ini, *.txt, *.json, *.js

🔐 Für jede Datei wird ein Backup mit .bak erstellt.

▶ Anwendung:
1. chmod +x replace_host25.sh
2. ./replace_host25.sh
